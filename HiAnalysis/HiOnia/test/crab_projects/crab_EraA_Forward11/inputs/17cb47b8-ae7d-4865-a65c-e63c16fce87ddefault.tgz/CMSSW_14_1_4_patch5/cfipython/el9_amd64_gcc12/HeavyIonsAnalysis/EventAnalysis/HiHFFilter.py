import FWCore.ParameterSet.Config as cms

def HiHFFilter(**kwargs):
  mod = cms.EDFilter('HiHFFilter',
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod

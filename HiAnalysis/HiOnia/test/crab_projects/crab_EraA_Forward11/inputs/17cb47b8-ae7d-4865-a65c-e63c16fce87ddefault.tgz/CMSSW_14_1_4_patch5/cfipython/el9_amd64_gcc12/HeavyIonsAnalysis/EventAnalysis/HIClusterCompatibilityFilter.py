import FWCore.ParameterSet.Config as cms

def HIClusterCompatibilityFilter(**kwargs):
  mod = cms.EDFilter('HIClusterCompatibilityFilter',
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod

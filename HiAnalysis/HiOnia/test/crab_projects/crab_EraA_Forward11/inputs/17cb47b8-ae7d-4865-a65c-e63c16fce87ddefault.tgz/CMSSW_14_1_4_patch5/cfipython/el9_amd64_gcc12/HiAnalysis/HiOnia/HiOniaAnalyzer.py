import FWCore.ParameterSet.Config as cms

def HiOniaAnalyzer(**kwargs):
  mod = cms.EDAnalyzer('HiOniaAnalyzer',
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod

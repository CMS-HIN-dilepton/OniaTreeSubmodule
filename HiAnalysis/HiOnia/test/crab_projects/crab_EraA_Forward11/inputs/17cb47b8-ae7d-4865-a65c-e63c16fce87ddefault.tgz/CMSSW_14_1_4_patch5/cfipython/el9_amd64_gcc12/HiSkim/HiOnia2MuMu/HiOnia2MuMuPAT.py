import FWCore.ParameterSet.Config as cms

def HiOnia2MuMuPAT(**kwargs):
  mod = cms.EDProducer('HiOnia2MuMuPAT',
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod

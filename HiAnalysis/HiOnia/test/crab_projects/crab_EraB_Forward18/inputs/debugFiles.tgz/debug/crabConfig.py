from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.transferLogs = False
config.General.requestName = 'EraB_Forward18'
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.psetName = 'hioniaanalyzer_UPC2024_PromptReco_cfg.py'
config.JobType.maxMemoryMB = 2000
config.JobType.pluginName = 'Analysis'
config.JobType.allowUndistributedCMSSW = True
config.JobType.numCores = 2
config.section_('Data')
config.Data.splitting = 'EventAwareLumiBased'
config.Data.unitsPerJob = 30000000
config.Data.inputDBS = 'global'
config.Data.runRange = '387853-389000'
config.Data.outLFNDirBase = '/store/user/fdamas/PbPb2024/UPC/'
config.Data.allowNonValidInputDataset = True
config.Data.inputDataset = '/HIForward18/HIRun2024B-PromptReco-v1/MINIAOD'
config.Data.lumiMask = '/eos/cms/store/group/phys_heavyions/sayan/HIN_run3_pseudo_JSON/HIPhysicsRawPrime_2024/Golden_387853_continue_L1DeadTimeCut10percent.txt'
config.Data.outputDatasetTag = 'EraB'
config.Data.publication = False
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
